
package com.example.localsocial.data

import androidx.room.*

@Dao
interface MessageDao {
    @Query("SELECT * FROM Message WHERE (fromUserId = :a AND toUserId = :b) OR (fromUserId = :b AND toUserId = :a) ORDER BY createdAt ASC")
    suspend fun conversation(a: Long, b: Long): List<Message>

    @Insert
    suspend fun insert(message: Message): Long

    @Delete
    suspend fun delete(message: Message)
}
