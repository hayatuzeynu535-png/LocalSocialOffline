
package com.example.localsocial.data

import androidx.room.*

@Dao
interface CommentDao {
    @Query("SELECT * FROM Comment WHERE postId = :postId ORDER BY createdAt ASC")
    suspend fun getForPost(postId: Long): List<Comment>

    @Insert
    suspend fun insert(comment: Comment): Long

    @Delete
    suspend fun delete(comment: Comment)
}
