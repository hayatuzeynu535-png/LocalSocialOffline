
package com.example.localsocial.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(primaryKeys = ["postId", "userId"])
data class Like(
    val postId: Long,
    val userId: Long,
    val createdAt: Long = System.currentTimeMillis()
)
