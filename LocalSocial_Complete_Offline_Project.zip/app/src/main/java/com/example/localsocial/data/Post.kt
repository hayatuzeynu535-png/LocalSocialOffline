
package com.example.localsocial.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Post(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val text: String?,
    val mediaPath: String?,
    val mediaType: String?, // "image" or "video"
    val createdAt: Long = System.currentTimeMillis()
)
