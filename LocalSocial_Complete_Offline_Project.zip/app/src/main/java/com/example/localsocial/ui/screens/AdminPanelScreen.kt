
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.navigation.NavHostController

@Composable
fun AdminPanelScreen(navController: NavHostController) {
    Text("Admin Panel - manage users/posts (demo)")
}
