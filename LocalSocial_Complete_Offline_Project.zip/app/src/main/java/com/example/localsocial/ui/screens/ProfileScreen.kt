
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.navigation.NavHostController

@Composable
fun ProfileScreen(navController: NavHostController, userId: String) {
    Text("Profile for user: $userId (demo)")
}
