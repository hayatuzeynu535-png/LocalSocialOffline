
package com.example.localsocial.repo

import android.content.Context
import androidx.room.Room
import com.example.localsocial.data.*

class Repository private constructor(context: Context) {
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "localsocial.db").build()
    private val userDao = db.userDao()
    private val postDao = db.postDao()
    private val likeDao = db.likeDao()
    private val commentDao = db.commentDao()
    private val messageDao = db.messageDao()

    suspend fun createUser(user: User): Long = userDao.insert(user)
    suspend fun findUserByEmail(email: String): User? = userDao.getByEmail(email)
    suspend fun getAllPosts(): List<Post> = postDao.getAll()
    suspend fun createPost(post: Post): Long = postDao.insert(post)
    // more wrappers...

    companion object {
        @Volatile private var INSTANCE: Repository? = null
        fun getInstance(context: Context): Repository {
            return INSTANCE ?: synchronized(this) {
                val inst = Repository(context)
                INSTANCE = inst
                inst
            }
        }
    }
}
