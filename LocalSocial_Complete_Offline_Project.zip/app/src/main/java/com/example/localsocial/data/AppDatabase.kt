
package com.example.localsocial.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [User::class, Post::class, Like::class, Comment::class, Message::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao
    abstract fun likeDao(): LikeDao
    abstract fun commentDao(): CommentDao
    abstract fun messageDao(): MessageDao
}
