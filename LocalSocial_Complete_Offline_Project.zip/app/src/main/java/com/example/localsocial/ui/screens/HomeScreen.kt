
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.navigation.NavHostController
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material.Button

@Composable
fun HomeScreen(navController: NavHostController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Home Feed (offline demo)")
        Button(onClick = { navController.navigate("create") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Create Post")
        }
        Button(onClick = { navController.navigate("messages") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Messages")
        }
        Button(onClick = { navController.navigate("admin") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Admin Panel")
        }
        Button(onClick = { navController.navigate("settings") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Settings")
        }
    }
}
