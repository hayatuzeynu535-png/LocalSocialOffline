
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.navigation.NavHostController

@Composable
fun CreatePostScreen(navController: NavHostController) {
    Text("Create Post - choose image or video (demo)")
}
