
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text

@Composable
fun SettingsScreen(navController: androidx.navigation.NavHostController) {
    Text("Settings (demo)")
}
