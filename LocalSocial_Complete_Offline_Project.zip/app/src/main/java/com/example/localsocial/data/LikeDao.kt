
package com.example.localsocial.data

import androidx.room.*

@Dao
interface LikeDao {
    @Query("SELECT * FROM `Like` WHERE postId = :postId")
    suspend fun getForPost(postId: Long): List<Like>

    @Insert
    suspend fun insert(like: Like)

    @Delete
    suspend fun delete(like: Like)
}
