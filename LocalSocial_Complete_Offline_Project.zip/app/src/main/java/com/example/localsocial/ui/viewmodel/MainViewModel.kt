
package com.example.localsocial.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.localsocial.repo.Repository
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = Repository.getInstance(application.applicationContext)

    fun registerUser(email: String, displayName: String, passwordHash: String, onResult: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repo.createUser(com.example.localsocial.data.User(email = email, displayName = displayName, passwordHash = passwordHash))
            onResult(id)
        }
    }

    // Add other ViewModel helpers...
}
