
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "auth") {
        composable("auth") { AuthScreen(navController) }
        composable("home") { HomeScreen(navController) }
        composable("profile/{userId}") { backStack ->
            val id = backStack.arguments?.getString("userId") ?: "0"
            ProfileScreen(navController, id)
        }
        composable("create") { CreatePostScreen(navController) }
        composable("messages") { MessagesScreen(navController) }
        composable("admin") { AdminPanelScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
    }
}
