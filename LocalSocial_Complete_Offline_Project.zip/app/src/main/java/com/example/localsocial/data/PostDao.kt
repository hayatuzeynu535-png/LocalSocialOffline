
package com.example.localsocial.data

import androidx.room.*

@Dao
interface PostDao {
    @Query("SELECT * FROM Post ORDER BY createdAt DESC")
    suspend fun getAll(): List<Post>

    @Insert
    suspend fun insert(post: Post): Long

    @Update
    suspend fun update(post: Post)

    @Delete
    suspend fun delete(post: Post)
}
