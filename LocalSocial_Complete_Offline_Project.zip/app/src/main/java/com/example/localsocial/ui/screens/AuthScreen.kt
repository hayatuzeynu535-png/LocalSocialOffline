
package com.example.localsocial.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.navigation.NavHostController
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField

@Composable
fun AuthScreen(navController: NavHostController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("LocalSocial - Offline Demo")
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Email") })
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Password") })
        Button(onClick = { navController.navigate("home") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Login (demo)")
        }
        Button(onClick = { navController.navigate("home") }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Register (demo)")
        }
    }
}
