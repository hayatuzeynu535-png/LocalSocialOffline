
LocalSocial - Complete Offline Android project (Kotlin + Jetpack Compose + Room)

Goal:
Produce an installable Android APK without installing Android Studio locally — use CI (GitHub Actions) to build and download the artifact.

What I added in this package:
- Full Room entities & DAOs for User, Post, Like, Comment, Message.
- Simple repository and ViewModel stubs.
- Navigation and placeholder screens for Auth, Home, Profile, Create Post, Messages, Admin Panel, Settings.
- GitHub Actions workflow at `.github/workflows/android-build.yml` that builds a debug APK and uploads it as an artifact.
- Instructions below to build the APK on GitHub (no Android Studio required).

How to get an APK WITHOUT installing Android Studio (use GitHub Actions):
1. Create a new **private** or **public** GitHub repository.
2. Upload the entire project folder contents (this repo) to the repository root. You can do this by:
   - Initializing the folder as a git repo and pushing:
     ```
     git init
     git add .
     git commit -m "Initial LocalSocial offline project"
     git branch -M main
     git remote add origin https://github.com/<your-username>/<repo>.git
     git push -u origin main
     ```
   - Or upload via GitHub web UI (drag-and-drop).

3. After pushing, go to **Actions** in the GitHub repository UI. The workflow `Android CI - Build APK` will run automatically (or you can trigger it via "Run workflow").

4. When the workflow finishes, open the workflow run and download the artifact **app-debug-apk**. The artifact will be the generated `app-debug.apk`.

5. Transfer the APK to your Android phone and install (allow "Install unknown apps" for your file manager/browser). The app is offline-first and uses Room for local storage.

Notes, limitations and security:
- I cannot compile or provide an APK directly from this environment. The GitHub Actions workflow will compile the APK for you on GitHub's runners; you do not need Android Studio.
- If the build fails on GitHub due to missing Gradle wrapper, the provided workflow installs `gradle` as a fallback. For reliability, consider adding the Gradle wrapper files (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar`) to the repo — I can add them for you (but the jar is binary; I can include a small shim).
- This project is fully offline; all data is stored in Room locally on the device. Media picking requires user interaction and device storage permissions (the app will request them at runtime).
- For a production-ready signed release APK, generate a keystore locally and configure signing in `app/build.gradle.kts`. The README includes earlier instructions for signing.

Want me to:
A) Add the Gradle wrapper files and a working `gradlew` (recommended), or
B) Add more complete UIs (Edit Profile, Like/Comment UI, Media picker implementation), or
C) Add signed-release signing instructions and CI secret integration?

Reply with A, B, or C and I'll update the zip for you.

